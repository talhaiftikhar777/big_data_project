from t3 import feature_vectors_column_df
import csv
import pandas as pd

# Function to read CSV file
def read_csv_file(file_path):
    data = []
    with open(file_path, 'r', encoding='utf-8') as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            data.append(row)
    return data

# Example usage:
file_path1 = 'D:/bigdataproj/genres.csv'
file_path2 = 'D:/bigdataproj/raw_genres.csv'
file_path3 = 'D:/bigdataproj/raw_tracks.csv'

# Read CSV files into DataFrames
csv_data1 = read_csv_file(file_path1)
df1 = pd.DataFrame(csv_data1[1:], columns=csv_data1[0])

csv_data2 = read_csv_file(file_path2)
df2 = pd.DataFrame(csv_data2[1:], columns=csv_data2[0])

csv_data3 = read_csv_file(file_path3)
df3 = pd.DataFrame(csv_data3[1:], columns=csv_data3[0])

# Remove unnecessary columns from df1 and df2
columns_to_delete_df1 = ['#tracks', 'parent']
df1.drop(columns_to_delete_df1, axis=1, inplace=True)

column_indices_to_delete_df2 = [1, 2]
df2.drop(df2.columns[column_indices_to_delete_df2], axis=1, inplace=True)

# Remove unnecessary columns from df3
column_indices_to_delete_df3 = [0, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 38]
df3.drop(df3.columns[column_indices_to_delete_df3], axis=1, inplace=True)

# Merge df1 and df2 based on 'genre_id' column
merged_df_1_2 = pd.merge(df1, df2, on='genre_id')

# Concatenate merged_df_1_2 and df3 along the columns axis
merged_df = pd.concat([merged_df_1_2, df3], axis=1)

# Remove rows with null values
merged_df.dropna(inplace=True)

# Assuming you have two dataframes: feature_vectors_column_df and metadata_df
# Merge the dataframes using the feature vectors as the first column
final_df = pd.concat([feature_vectors_column_df, merged_df], axis=1)

# Convert the DataFrame to key-value pairs with feature vectors as keys
key_value_pairs = final_df.to_dict(orient='records')

# Display key-value pairs
print("Key-Value Pairs:")
for pair in key_value_pairs:
    print(pair)
