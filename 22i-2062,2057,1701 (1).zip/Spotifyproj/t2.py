import os
import zipfile
import tempfile
import numpy as np
import librosa
from sklearn import preprocessing
from pymongo import MongoClient

# Function to extract MFCC features from an audio file with fixed length
def extract_mfcc(audio_file, num_mfcc=13, max_frames=100):
    # Load audio file
    y, sr = librosa.load(audio_file)

    # Extract MFCC features
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=num_mfcc)

    # Normalize MFCCs
    mfccs_normalized = preprocessing.scale(mfccs, axis=1)

    # Ensure fixed length by padding or truncating
    if mfccs_normalized.shape[1] < max_frames:
        mfccs_normalized = np.pad(mfccs_normalized, ((0, 0), (0, max_frames - mfccs_normalized.shape[1])), mode='constant')
    else:
        mfccs_normalized = mfccs_normalized[:, :max_frames]

    return mfccs_normalized.flatten()  # Flatten MFCC matrix into a 1D array


# Function to extract MFCC features from audio files in a zip file and store in MongoDB
def extract_mfcc_from_zip(zip_file, num_mfcc=13):
    feature_vectors = []
    file_names = []

    try:
        # Connect to MongoDB
        client = MongoClient('mongodb://localhost:27017/')
        db = client['your_database']  # Replace 'your_database' with your actual database name
        collection = db['mfcc_features']  # Collection to store MFCC features

        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            zip_contents = zip_ref.namelist()

            with tempfile.TemporaryDirectory() as tmp_dir:
                zip_ref.extractall(tmp_dir)

                # Traverse subdirectories and process audio files
                for root, dirs, files in os.walk(tmp_dir):
                    for filename in files:
                        if filename.endswith('.mp3'):  # Assuming audio files are in MP3 format
                            audio_file_path = os.path.join(root, filename)

                            # Extract MFCC features
                            mfcc_vector = extract_mfcc(audio_file_path, num_mfcc)
                            feature_vectors.append(mfcc_vector)
                            file_names.append(filename)

                            # Insert into MongoDB
                            document = {
                                'file_name': filename,
                                'mfcc_features': mfcc_vector.tolist()
                            }
                            collection.insert_one(document)
                            print("Stored:", filename)  # Print confirmation

    except Exception as e:
        print("Error occurred:", e)

    return np.array(feature_vectors), file_names

# Example usage:
zip_file_path = 'D:/bigdataproj/sharedata/002.zip'
feature_vectors, file_names = extract_mfcc_from_zip(zip_file_path)
print("Extracted MFCC feature vectors for", len(feature_vectors), "audio files.")
print("Feature vector shape:", feature_vectors.shape)
print("File names:", file_names)



import pandas as pd

# Check if feature vectors were extracted successfully and there are feature vectors available
if feature_vectors is not None and len(feature_vectors) > 0:
    # Select the first 50 feature vectors
    feature_vectors_list = feature_vectors[:50]  # Select the first 50 feature vectors
    
    # Reshape each feature vector to be one-dimensional
    feature_vectors_list_1d = [feature_vector.flatten() for feature_vector in feature_vectors_list]
    
    # Convert the list of feature vectors to a DataFrame column
    feature_vectors_column_df = pd.DataFrame({'Feature_Vectors': feature_vectors_list_1d})
else:
    print("No audio files found or extraction failed.")


feature_vectors_column_df
