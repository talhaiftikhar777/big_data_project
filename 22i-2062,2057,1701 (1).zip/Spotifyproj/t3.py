import os
import numpy as np
import librosa
from sklearn.preprocessing import MinMaxScaler
import zipfile
import tempfile
import warnings

# Function to preprocess audio data
def preprocess_audio(y):
    # Apply clipping to remove outliers
    y_clipped = np.clip(y, -1.0, 1.0)
    # Apply normalization
    y_normalized = librosa.util.normalize(y_clipped)
    return y_normalized

# Function to extract MFCC features from an audio file with fixed length
def extract_mfcc(audio_file, num_mfcc=13, max_frames=50):
    try:
        # Load audio file
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            y, sr = librosa.load(audio_file, sr=None)

        # Preprocess audio data
        y_preprocessed = preprocess_audio(y)
        
        # Extract MFCC features
        mfccs = librosa.feature.mfcc(y=y_preprocessed, sr=sr, n_mfcc=num_mfcc)
        
        # Normalize MFCCs
        scaler = MinMaxScaler()
        mfccs_normalized = scaler.fit_transform(mfccs.T).T
        
        # Ensure fixed length by padding or truncating
        if mfccs_normalized.shape[1] < max_frames:
            mfccs_normalized = np.pad(mfccs_normalized, ((0, 0), (0, max_frames - mfccs_normalized.shape[1])), mode='constant')
        else:
            mfccs_normalized = mfccs_normalized[:, :max_frames]
        
        return mfccs_normalized.flatten()  # Flatten MFCC matrix into a 1D array
    
    except Exception as e:
        print("Error occurred while processing audio file:", e)
        return None

# Function to extract MFCC features from audio files in a zip file
def extract_mfcc_from_zip(zip_file_path, max_files=100):
    feature_vectors = []
    file_names = []
    try:
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            # Create a temporary directory to extract audio files
            with tempfile.TemporaryDirectory() as tmp_dir:
                zip_ref.extractall(tmp_dir)
                count = 0
                # Iterate over extracted files
                for root, dirs, files in os.walk(tmp_dir):
                    for file in files:
                        if file.endswith(".mp3"):
                            audio_file = os.path.join(root, file)
                            mfcc_features = extract_mfcc(audio_file)
                            if mfcc_features is not None:
                                feature_vectors.append(mfcc_features)
                                file_names.append(file)
                                count += 1
                                if count >= max_files:
                                    break
                    if count >= max_files:
                        break
        
        return np.array(feature_vectors), file_names
    
    except Exception as e:
        print("Error occurred while processing zip file:", e)
        return None, None


# Example usage:
zip_file_path = 'D:/bigdataproj/sharedata/002.zip'
feature_vectors, file_names = extract_mfcc_from_zip(zip_file_path)
if feature_vectors is not None and len(feature_vectors) > 0:
    print("Extracted MFCC feature vectors for", len(feature_vectors), "audio files.")
    print("Feature vector shape:", feature_vectors.shape)
    print("File names:", file_names)
else:
    print("No audio files found or extraction failed.")





import pandas as pd

# Check if feature vectors were extracted successfully and there are feature vectors available
if feature_vectors is not None and len(feature_vectors) > 0:
    # Select the first 50 feature vectors
    feature_vectors_list = feature_vectors[:50]  # Select the first 50 feature vectors
    
    # Reshape each feature vector to be one-dimensional
    feature_vectors_list_1d = [feature_vector.flatten() for feature_vector in feature_vectors_list]
    
    # Convert the list of feature vectors to a DataFrame column
    feature_vectors_column_df = pd.DataFrame({'Feature_Vectors': feature_vectors_list_1d})
else:
    print("No audio files found or extraction failed.")


feature_vectors_column_df