from t4 import key_value_pairs
from pymongo import MongoClient
from pyspark.sql import SparkSession
from pyspark.ml.recommendation import ALS
from pyspark.ml.evaluation import RegressionEvaluator

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['your_database'] 
collection = db['key_value_pairs']  # Collection to store key-value pairs

# Read data from MongoDB into a DataFrame
spark = SparkSession.builder \
    .appName("Music Recommendation") \
    .config("spark.mongodb.input.uri", "mongodb://localhost:27017/your_database.key_value_pairs") \
    .config("spark.mongodb.output.uri", "mongodb://localhost:27017/your_database.key_value_pairs") \
    .getOrCreate()

df = spark.read.format("com.mongodb.spark.sql.DefaultSource").load()

# Split the data into training and testing datasets
(training, test) = df.randomSplit([0.8, 0.2])

# Build the recommendation model using ALS
als = ALS(maxIter=5, regParam=0.01, userCol="user_id", itemCol="item_id", ratingCol="rating",
          coldStartStrategy="drop")
model = als.fit(training)

# Evaluate the model by computing RMSE on the test data
predictions = model.transform(test)
evaluator = RegressionEvaluator(metricName="rmse", labelCol="rating", predictionCol="prediction")
rmse = evaluator.evaluate(predictions)
print("Root Mean Squared Error (RMSE) = " + str(rmse))

# Stop the SparkSession
spark.stop()

# Close the connection to MongoDB
client.close()
