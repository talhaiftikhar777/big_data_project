import os
import zipfile
import tempfile
import numpy as np
import librosa
from sklearn import preprocessing

# Function to extract MFCC features from an audio file with fixed length
def extract_mfcc(audio_file, num_mfcc=13, max_frames=100):
    # Load audio file
    y, sr = librosa.load(audio_file)

    # Extract MFCC features
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=num_mfcc)

    # Normalize MFCCs
    mfccs_normalized = preprocessing.scale(mfccs, axis=1)

    # Ensure fixed length by padding or truncating
    if mfccs_normalized.shape[1] < max_frames:
        mfccs_normalized = np.pad(mfccs_normalized, ((0, 0), (0, max_frames - mfccs_normalized.shape[1])), mode='constant')
    else:
        mfccs_normalized = mfccs_normalized[:, :max_frames]

    return mfccs_normalized.flatten()  # Flatten MFCC matrix into a 1D array


# Function to extract MFCC features from audio files in a zip file
def extract_mfcc_from_zip(zip_file, num_mfcc=13):
    feature_vectors = []
    file_names = []

    try:
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            zip_contents = zip_ref.namelist()
            print("Contents of the zip file:", zip_contents)

            with tempfile.TemporaryDirectory() as tmp_dir:
                zip_ref.extractall(tmp_dir)
                print("Extracted files to temporary directory:", os.listdir(tmp_dir))

                # Traverse subdirectories and process audio files
                for root, dirs, files in os.walk(tmp_dir):
                    for filename in files:
                        if filename.endswith('.mp3'):  # Assuming audio files are in MP3 format
                            audio_file_path = os.path.join(root, filename)
                            print("Processing audio file:", audio_file_path)

                            # Extract MFCC features
                            mfcc_vector = extract_mfcc(audio_file_path, num_mfcc)
                            feature_vectors.append(mfcc_vector)
                            file_names.append(filename)

                            print("MFCC extraction successful for:", filename)

    except Exception as e:
        print("Error occurred:", e)

    return np.array(feature_vectors), file_names

# Example usage:
zip_file_path = 'D:/bigdataproj/sharedata/002.zip'
feature_vectors, file_names = extract_mfcc_from_zip(zip_file_path)
print("Extracted MFCC feature vectors for", len(feature_vectors), "audio files.")
print("Feature vector shape:", feature_vectors.shape)
print("File names:", file_names)
