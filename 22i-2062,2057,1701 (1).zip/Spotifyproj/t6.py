import t5
from t4 import key_value_pairs
from pymongo import MongoClient
from pyspark.sql import SparkSession
from pyspark.ml.recommendation import ALS
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['your_database']  # Replace 'your_database' with your actual database name
collection = db['key_value_pairs']  # Collection to store key-value pairs

# Insert data into MongoDB
for pair in key_value_pairs:
    collection.insert_one(pair)

# Create a SparkSession
spark = SparkSession.builder \
    .appName("Music Recommendation") \
    .config("spark.mongodb.input.uri", "mongodb://localhost:27017/your_database.key_value_pairs") \
    .config("spark.mongodb.output.uri", "mongodb://localhost:27017/your_database.key_value_pairs") \
    .getOrCreate()

# Read data from MongoDB into a DataFrame
df = spark.read.format("com.mongodb.spark.sql.DefaultSource").load()

# Split the data into training and testing datasets
(training, test) = df.randomSplit([0.8, 0.2])

# Build the recommendation model using ALS
als = ALS(userCol="user_id", itemCol="item_id", ratingCol="rating",
          coldStartStrategy="drop")

# Define a grid of hyperparameters to search
param_grid = ParamGridBuilder() \
    .addGrid(als.rank, [10, 20, 30]) \
    .addGrid(als.maxIter, [5, 10, 15]) \
    .addGrid(als.regParam, [0.01, 0.05, 0.1]) \
    .build()

# Define an evaluator
evaluator = RegressionEvaluator(metricName="rmse", labelCol="rating", predictionCol="prediction")

# Define cross-validation
crossval = CrossValidator(estimator=als,
                          estimatorParamMaps=param_grid,
                          evaluator=evaluator,
                          numFolds=3)

# Train the recommendation model using cross-validation
cv_model = crossval.fit(training)

# Evaluate the model on the test set
predictions = cv_model.transform(test)
rmse = evaluator.evaluate(predictions)
print("Root Mean Squared Error (RMSE) = " + str(rmse))

# Analyze the results
best_model = cv_model.bestModel
print("Best Model: " + str(best_model))

# Stop the SparkSession
spark.stop()

# Close the connection to MongoDB
client.close()
