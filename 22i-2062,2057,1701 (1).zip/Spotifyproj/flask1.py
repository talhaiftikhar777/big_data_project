from flask import Flask, render_template
from pymongo import MongoClient
from pyspark.sql import SparkSession
from pyspark.ml.recommendation import ALS
from pyspark.ml.evaluation import RegressionEvaluator


app = Flask(__name__)

# MongoDB connection settings
MONGODB_URI = 'mongodb://localhost:27017/'
DATABASE_NAME = 'your_database'
COLLECTION_NAME = 'key_value_pairs'

# Spark session settings
SPARK_APP_NAME = 'Music Recommendation'
SPARK_MONGODB_INPUT_URI = f'mongodb://localhost:27017/{DATABASE_NAME}.{COLLECTION_NAME}'
SPARK_MONGODB_OUTPUT_URI = f'mongodb://localhost:27017/{DATABASE_NAME}.{COLLECTION_NAME}'

def train_recommendation_model():
    # Create a SparkSession
    spark = SparkSession.builder \
        .appName(SPARK_APP_NAME) \
        .config("spark.mongodb.input.uri", SPARK_MONGODB_INPUT_URI) \
        .config("spark.mongodb.output.uri", SPARK_MONGODB_OUTPUT_URI) \
        .getOrCreate()

    # Read data from MongoDB into a DataFrame
    df = spark.read.format("com.mongodb.spark.sql.DefaultSource").load()

    # Split the data into training and testing datasets
    (training, test) = df.randomSplit([0.8, 0.2])

    # Build the recommendation model using ALS
    als = ALS(maxIter=5, regParam=0.01, userCol="user_id", itemCol="item_id", ratingCol="rating",
              coldStartStrategy="drop")
    model = als.fit(training)

    # Evaluate the model by computing RMSE on the test data
    predictions = model.transform(test)
    evaluator = RegressionEvaluator(metricName="rmse", labelCol="rating", predictionCol="prediction")
    rmse = evaluator.evaluate(predictions)

    # Stop the SparkSession
    spark.stop()

    return model, rmse

@app.route('/')
def index():
    # Train the recommendation model
    model, rmse = train_recommendation_model()

    # Generate recommendations
    recommendations = model.recommendForAllUsers(5)  # Example: Get top 5 recommendations for all users

    # Close the connection to MongoDB
    client.close()

    return render_template('index.html', recommendations=recommendations)

if __name__ == '__main__':
    app.run(debug=True)
